import React from "react";
import "./style.css";

function Footer(props) {
  return <div className="foot"> 
  <h6 className="text">
  <a href="https://github.com/stephehutch">Visit my github</a>
  </h6>
  </div>
}

export default Footer;
